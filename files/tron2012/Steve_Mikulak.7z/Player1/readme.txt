Submission for Steve Mikulak.

The files in \Player1\Monte Risky are my main submission.

The files in \Player1\Exp are my 'fun' submission.
import java.awt.Color;
import java.awt.Point;
import java.lang.Math;

public class Player1 extends Player{	
	/** 
	 * This method will evaluate the current location of the player and generate 
	 * the best move to take (hopefully).
	 * 
	 * Possible methods to use:
	 * 		- public int[][] getMap()
	 * 			This method returns a 2d array of int which is the entire map.
	 * 			What you can do with this is:
	 * 				int[][] map = getMap();
	 * 				if (map[2][3]==Constant.PLAYER1)	//This checks if the position (2,3) is player1
	 * 				if (map[2][3]==Constant.PLAYER2)	//This checks if the position (2,3) is player2
	 * 				if (map[2][3]==Constant.WALL)		//This checks if the position (2,3) is a wall
	 * 				if (map[2][3]==Constant.PATH		//This checks if the position (2,3) is a path
	 * 
	 * 		- public Point getPlayer1Location()
	 * 			This method returns the current location of Player 1 (red) in terms
	 * 			of the index to the 2d map. To access the x index or y index, do this:
	 * 					Point test = getPlayer1Location();
	 * 					test.x;		//The row index of your current player
	 * 					test.y;		//The column index of your current player
	 * 
	 * 		- public Point getPlayer2Location()
	 * 			This method returns the current location of Player 2 (blue) in terms
	 * 			of the index to the 2d map. To access the x index or y index, do this:
	 * 					Point test = getPlayer2Location();
	 * 					test.x;		//The row index of your current player
	 * 					test.y;		//The column index of your current player
	 * 
	 * 		- public Point getPlayer1PrevLocation()
	 * 			This method returns the previous location of Player 1 (red) in terms
	 * 			of the index to the 2d map. To access the x index or y index, do this:
	 * 					Point test = getPlayer1PrevLocation();
	 * 					test.x;		//The row index of your current player
	 * 					test.y;		//The column index of your current player
	 * 
	 * 		- public Point getPlayer2PrevLocation()
	 * 			This method returns the previous location of Player 2 (blue) in terms
	 * 			of the index to the 2d map. To access the x index or y index, do this:
	 * 					Point test = getPlayer2PrevLocation();
	 * 					test.x;		//The row index of your current player
	 * 					test.y;		//The column index of your current player
	 * 		
	 * 		- public boolean safe(int x, int y)
	 * 			This method takes in two indexes corresponding to the 2d array and returns
	 * 			true if the indexes are within the bounds of the array.
	 * 			Example:
	 * 					if (safe(400,5)){
	 * 						System.out.println("test");
	 * 					}
	 * 			The code above will not print anything out because the map does not have
	 * 			400 rows and so the input parameters are out of the bounds (not in the map). 
	 * 		
	 * 
	 * @return Returns the direction that the player will move on its next move.
	 * Possible return directions (the move() method must return one of these):
	 * 		return Constant.UP;
	 * 		return Constant.DOWN;
	 * 		return Constant.LEFT;
	 * 		return Constant.RIGHT;
	 */
	
	boolean[][] bmap;
	
	private int maxMoves(int xcor, int ycor){
		if(!bmap[xcor][ycor]){
			bmap[xcor][ycor]=true;
			int count=1;
			if(safe(xcor+1,ycor)) count+=maxMoves(xcor+1,ycor);
			if(safe(xcor-1,ycor)) count+=maxMoves(xcor-1,ycor);
			if(safe(xcor,ycor+1)) count+=maxMoves(xcor,ycor+1);
			if(safe(xcor,ycor-1)) count+=maxMoves(xcor,ycor-1);
			return count;
		}
		
		return 0;
	}
	
	
	private boolean reachable(int x, int y){
		return (safe(x-1,y) && bmap[x-1][y]) || (safe(x+1,y) && bmap[x+1][y]) || (safe(x,y+1) && bmap[x][y+1]) || (safe(x,y-1) && bmap[x][y-1]);
	}
	
	
	
	
	private boolean safe(int x, int y){
		int[][] map=getMap();
		return checkBounds(x,y) && map[x][y]==Constant.PATH;
	}
	
	
	private int resetMax(int x, int y){
		bmap= new boolean[30][30];
		if(safe(x,y))
			return maxMoves(x,y);
		
		else
			return 0;
	}
	
	public int move(){
		Point curL = getPlayer1Location();
		Point prevL = getPlayer1PrevLocation();
		int curx = curL.x;
		int cury = curL.y;
		
		int prevx = prevL.x;
		int prevy = prevL.y;
		
		
		Point opL = getPlayer2Location();
		int opx=opL.x;
		int opy=opL.y;
		int[][] map=getMap();
		System.out.println(map[opx][opy]);
		
		
		if(curx>prevx){//Last move was right
			int up=resetMax(curx,cury-1);
			int right=resetMax(curx+1,cury);
			int down=resetMax(curx,cury+1);
			
			if(up==right && up==down && reachable(opx,opy)){
				int ud = 0;
				if(cury>opy) ud=Constant.UP;
				else ud=Constant.DOWN;
				if(Math.abs(curx-opx)>Math.abs(cury-opy) && curx<opx) return Constant.RIGHT;
				else return ud;
			}
			
			if(right>up && right>down) return Constant.RIGHT;
			if(up>down) return Constant.UP;
			return Constant.DOWN;
		}
		
		if(curx<prevx){//Last move was left
			int up=resetMax(curx,cury-1);
			int left=resetMax(curx-1,cury);
			int down=resetMax(curx,cury+1);
			
			if(up==left && up==down && reachable(opx,opy)){
				int ud = 0;
				if(cury>opy) ud=Constant.UP;
				else ud=Constant.DOWN;
				if(Math.abs(curx-opx)>Math.abs(cury-opy) && curx>opx) return Constant.LEFT;
				else return ud;
			}
			
			
			if(left>up && left>down) return Constant.LEFT;
			if(up>=down) return Constant.UP;
			return Constant.DOWN;
		}
		
		if(cury>prevy){//Last move was down
			int left=resetMax(curx-1,cury);
			int right=resetMax(curx+1,cury);
			int down=resetMax(curx,cury+1);
			
			if(right==left && right==down && reachable(opx,opy)){
				int lr = 0;
				if(curx>opx) lr=Constant.LEFT;
				else lr=Constant.RIGHT;
				if(Math.abs(cury-opy)>Math.abs(curx-opx) && cury<opy) return Constant.DOWN;
				else return lr;
			}
			
			if(left>=right && left>=down) return Constant.LEFT;
			if(right>=down) return Constant.RIGHT;
			return Constant.DOWN;
		}
		
		if(cury<prevy){//Last move was up
			int right=resetMax(curx+1,cury);
			int left=resetMax(curx-1,cury);
			int up=resetMax(curx,cury-1);
			
			if(right==left && right==up && reachable(opx,opy)){
				int lr = 0;
				if(curx>opx) lr=Constant.LEFT;
				else lr=Constant.RIGHT;
				if(Math.abs(cury-opy)>Math.abs(curx-opx) && cury>opy) return Constant.UP;
				else return lr;
			}
			
			
			if(right>=left && right>=up) return Constant.RIGHT;
			if(left>=up) return Constant.LEFT;
			return Constant.UP;
		}
		// Can you make it so that it keeps doing this until player1 cannot get to
		// player2 and then it starts "hugging"
		
		
		if(safe(curx,cury-1)) return Constant.UP;
		if(safe(curx,cury+1)) return Constant.DOWN;
		if(safe(curx-1,cury)) return Constant.LEFT;
		return Constant.RIGHT;
	}
		
	
	//DO NOT edit the following:
	public Player1(Color aColor, int x, int y, ProxyGame p){super(aColor, x, y, p);}
	public Player1(Color aColor){super(aColor);}
	public boolean isPlayer1() {return true;}
	public boolean isPlayer2() {return false;}
}

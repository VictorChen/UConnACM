import java.awt.Color;
import java.awt.Point;
import java.math.*;

public class Player2 extends Player {
    private int Max = 0;
    private int safeRight = 0;
    private int safeLeft = 0;
    private int safeUp = 0;
    private int safeDown = 0;
    private int Avoid = 30;
    private int direction = 0;
    private int headdist = 800;
    private Point target = null;

    
	boolean[][] bmap;
	
	private int maxMoves(int xcor, int ycor){
		if(!bmap[xcor][ycor]){
			bmap[xcor][ycor]=true;
			int count=1;
			if(safe(xcor+1,ycor)) count+=maxMoves(xcor+1,ycor);
			if(safe(xcor-1,ycor)) count+=maxMoves(xcor-1,ycor);
			if(safe(xcor,ycor+1)) count+=maxMoves(xcor,ycor+1);
			if(safe(xcor,ycor-1)) count+=maxMoves(xcor,ycor-1);
			return count;
		}
		
		return 0;
	}
	
	
	private boolean reachable(int x, int y){
		return (safe(x-1,y) && bmap[x-1][y]) || (safe(x+1,y) && bmap[x+1][y]) || (safe(x,y+1) && bmap[x][y+1]) || (safe(x,y-1) && bmap[x][y-1]);
	}
	
	
	
	
	private boolean safe(int x, int y){
		int[][] map=getMap();
		return checkBounds(x,y) && map[x][y]==Constant.PATH;
	}
	
	
	private int resetMax(int x, int y){
		bmap= new boolean[30][30];
		if(safe(x,y))
			return maxMoves(x,y);
		
		else
			return 0;
	}
    
	public int move(){
		Point curL = getPlayer2Location();
		Point prevL = getPlayer2PrevLocation();
		int curx = curL.x;
		int cury = curL.y;
		
		int prevx = prevL.x;
		int prevy = prevL.y;
		
		
		Point opL = getPlayer1Location();
		int opx=opL.x;
		int opy=opL.y;
		int[][] map=getMap();
		System.out.println(map[opx][opy]);
		
		
		if(curx>prevx){//Last move was right
			int up=resetMax(curx,cury-1);
			int right=resetMax(curx+1,cury);
			int down=resetMax(curx,cury+1);
			
			if(up==right && up==down && reachable(opx,opy)){
				int ud = 0;
				if(cury>opy) ud=Constant.UP;
				else ud=Constant.DOWN;
				if(Math.abs(curx-opx)>Math.abs(cury-opy) && curx<opx) return Constant.RIGHT;
				else return ud;
			}
			
			if(right>up && right>down) return Constant.RIGHT;
			if(up>down) return Constant.UP;
			return Constant.DOWN;
		}
		
		if(curx<prevx){//Last move was left
			int up=resetMax(curx,cury-1);
			int left=resetMax(curx-1,cury);
			int down=resetMax(curx,cury+1);
			
			if(up==left && up==down && reachable(opx,opy)){
				int ud = 0;
				if(cury>opy) ud=Constant.UP;
				else ud=Constant.DOWN;
				if(Math.abs(curx-opx)>Math.abs(cury-opy) && curx>opx) return Constant.LEFT;
				else return ud;
			}
			
			
			if(left>up && left>down) return Constant.LEFT;
			if(up>=down) return Constant.UP;
			return Constant.DOWN;
		}
		
		if(cury>prevy){//Last move was down
			int left=resetMax(curx-1,cury);
			int right=resetMax(curx+1,cury);
			int down=resetMax(curx,cury+1);
			
			if(right==left && right==down && reachable(opx,opy)){
				int lr = 0;
				if(curx>opx) lr=Constant.LEFT;
				else lr=Constant.RIGHT;
				if(Math.abs(cury-opy)>Math.abs(curx-opx) && cury<opy) return Constant.DOWN;
				else return lr;
			}
			
			if(left>=right && left>=down) return Constant.LEFT;
			if(right>=down) return Constant.RIGHT;
			return Constant.DOWN;
		}
		
		if(cury<prevy){//Last move was up
			int right=resetMax(curx+1,cury);
			int left=resetMax(curx-1,cury);
			int up=resetMax(curx,cury-1);
			
			if(right==left && right==up && reachable(opx,opy)){
				int lr = 0;
				if(curx>opx) lr=Constant.LEFT;
				else lr=Constant.RIGHT;
				if(Math.abs(cury-opy)>Math.abs(curx-opx) && cury>opy) return Constant.UP;
				else return lr;
			}
			
			
			if(right>=left && right>=up) return Constant.RIGHT;
			if(left>=up) return Constant.LEFT;
			return Constant.UP;
		}
		// Can you make it so that it keeps doing this until player1 cannot get to
		// player2 and then it starts "hugging"
		
		
		if(safe(curx,cury-1)) return Constant.UP;
		if(safe(curx,cury+1)) return Constant.DOWN;
		if(safe(curx-1,cury)) return Constant.LEFT;
		return Constant.RIGHT;
	}

    // DO NOT edit the following:
    // DO NOT edit the following:
    public Player2(Color aColor, int x, int y, ProxyGame p) {
        super(aColor, x, y, p);
    }

    public Player2(Color aColor) {
        super(aColor);
    }

    public boolean isPlayer1() {
        return false;
    }

    public boolean isPlayer2() {
        return true;
    }
}